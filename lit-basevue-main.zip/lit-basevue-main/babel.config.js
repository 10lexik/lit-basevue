const plugins = []

module.exports = {
    presets: [
        '@vue/cli-plugin-babel/preset'
    ],
    plugins: plugins
}
