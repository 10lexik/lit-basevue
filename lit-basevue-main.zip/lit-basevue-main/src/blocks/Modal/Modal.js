'use strict'

export default {
    name: 'Modal'
}
