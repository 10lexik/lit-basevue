<template>
    <div class="swiper-slide">
        <!-- @slot Content for each slide -->
        <slot></slot>
    </div>
</template>

<style scoped lang="scss" src="./Slide.scss"></style>
<script src="./Slide.js"></script>
