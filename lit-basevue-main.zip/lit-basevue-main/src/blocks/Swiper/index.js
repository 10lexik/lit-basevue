import Swiper from './Swiper.vue'
import Slide from './Slide/Slide.vue'

export {
    Swiper,
    Slide
}
