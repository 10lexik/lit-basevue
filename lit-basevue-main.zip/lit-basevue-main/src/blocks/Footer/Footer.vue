<template>
    <section class="footer">
        <div class="footer__wrapper">
            <div class='footer__carterose'>
                <Img src="logo-pink-brand-footer.svg" alt="Carte Rose à" inlineSvg class="footer__carterose--img" />
            </div>
            <div class="footer__brand">
                <Img src="https://img.logoipsum.com/290.svg" alt="" class="footer__brand--img" />
            </div>
        </div>
        <span class="footer__mentions">&copy;Tous droits réservés.</span>
    </section>
</template>

<style scoped lang="scss" src="./Footer.scss"></style>
<script src="./Footer.js"></script>
