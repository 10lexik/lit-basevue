Timer :

```vue
<Timer
    title="Veepee's Exclu of the day"
/>
```
