Reinsurance (iconGrid) :

```vue
<Reinsurance
    variant="iconGrid"
    :title="[{ type: 'h3', text: 'Lorem Ipsum title' }, { type: 'smallBody', text: 'SUBTITLE' }]"
    :list="[
        { img: 'https://picsum.photos/400/300?random=1', title: 'Lorem ipsum dolor sit ' },
        { img: 'https://picsum.photos/400/300?random=1', title: 'Lorem ipsum dolor sit ' },
        { img: 'https://picsum.photos/400/300?random=1', title: 'Lorem ipsum dolor sit ' },
        { img: 'https://picsum.photos/400/300?random=1', title: 'Lorem ipsum dolor sit ' }
]"/>
```

Reinsurance (iconList) :

```vue
<Reinsurance
    variant="iconList"
    :title="[{ type: 'h3', text: 'Lorem Ipsum title' }, { type: 'smallBody', text: 'SUBTITLE' }]"
    :list="[
        { img: 'https://picsum.photos/400/300?random=1', title: 'Lorem ipsum dolor sit ' },
        { img: 'https://picsum.photos/400/300?random=1', title: 'Lorem ipsum dolor sit ' },
        { img: 'https://picsum.photos/400/300?random=1', title: 'Lorem ipsum dolor sit ' },
        { img: 'https://picsum.photos/400/300?random=1', title: 'Lorem ipsum dolor sit ' }
]"/>
```

Reinsurance (horizontalList) :

```vue
<Reinsurance
    variant="horizontalList"
    :title="[{ type: 'h3', text: 'Lorem Ipsum title' }, { type: 'smallBody', text: 'SUBTITLE' }]"
    :list="[
        { img: 'https://picsum.photos/400/300?random=1', title: 'Lorem ipsum dolor sit ' },
        { img: 'https://picsum.photos/400/300?random=1', title: 'Lorem ipsum dolor sit ' },
        { img: 'https://picsum.photos/400/300?random=1', title: 'Lorem ipsum dolor sit ' },
        { img: 'https://picsum.photos/400/300?random=1', title: 'Lorem ipsum dolor sit ' }
]"/>
```

