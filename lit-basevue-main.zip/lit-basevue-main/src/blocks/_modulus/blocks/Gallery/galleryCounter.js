let galleryCounter = 0
export default galleryCounter
