let htCounter = 0
export default htCounter
