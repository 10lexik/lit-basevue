Header (TOP) (not working on styleguide) :

```vue
<!--
<Header
    variant="top"
    :title="[{ type: 'h3', text: 'Lorem Ipsum title' }, { type: 'smallBody', text: 'SUBTITLE' }]"
    text="Lorem Ipsum is simply dummy text"
    textAlign="center"
    :textScroll="{text:'DISCOVER THE OFFER', type: 'ml'}"
    logo="https://dummyimage.com/640x360/fff/aaa"
/>
-->
```

Header (BOTTOM) (not working on styleguide) :

```vue
<!--
<Header
    variant="bottom"
    :title="[{ type: 'h3', text: 'Lorem Ipsum title' }, { type: 'smallBody', text: 'SUBTITLE' }]"
    text="Lorem Ipsum is simply dummy text"
    textAlign="center"
    :textScroll="{text:'DISCOVER THE OFFER', type: 'ml'}"
    logo="https://dummyimage.com/640x360/fff/aaa"
/>
-->
```

Header (POP-IN) (not working on styleguide) :

```vue
<!--
<Header
    variant="pop-in"
    :title="[{ type: 'h3', text: 'Lorem Ipsum title' }, { type: 'smallBody', text: 'SUBTITLE' }]"
    text="Lorem Ipsum is simply dummy text"
    textAlign="center"
    :textScroll="{text:'DISCOVER THE OFFER', type: 'ml'}"
    logo="https://dummyimage.com/640x360/fff/aaa"
/>
-->
```

Header (BLOCK) (not working on styleguide) :

```vue
<!--
<Header
    variant="block"
    :title="[{ type: 'h3', text: 'Lorem Ipsum title' }, { type: 'smallBody', text: 'SUBTITLE' }]"
    text="Lorem Ipsum is simply dummy text"
    textAlign="center"
    :textScroll="{text:'DISCOVER THE OFFER', type: 'ml'}"
    logo="https://dummyimage.com/640x360/fff/aaa"
/>
-->
```

Header (CENTER) (not working on styleguide) :

```vue
<!--
<Header
    variant="center"
    :title="[{ type: 'h3', text: 'Lorem Ipsum title' }, { type: 'smallBody', text: 'SUBTITLE' }]"
    text="Lorem Ipsum is simply dummy text"
    textAlign="center"
    :textScroll="{text:'DISCOVER THE OFFER', type: 'ml'}"
    logo="https://dummyimage.com/640x360/fff/aaa"
/>
-->
```
