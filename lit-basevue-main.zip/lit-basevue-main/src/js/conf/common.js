module.exports = {
	"dumbo": {
		"operationCode": "[opcode]"
	},
	"operation": {
		"date": "December 31, 2022 07:00:00"
	}
};
