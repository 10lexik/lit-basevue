Default behaviour using each of EasterEgg src and placeholders :
```vue
<EasterEggSummary />
```

Using custom placeholders :
```vue
<EasterEggSummary
    placeholder="https://via.placeholder.com/200x200/ffAf00?text=Not%20found"
    foundPlaceholder="https://via.placeholder.com/200x200/green?text=Found"
/>
```
