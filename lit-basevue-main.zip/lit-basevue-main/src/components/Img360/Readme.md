```vue
<Img360 :xThreshold="30" :src="[
    'https://brand-media-demo.front.vpgrp.net/experiences/crb-renault9/img/X071VEVP2WE_ENS_MDL2PSL1SERIELIM1_TEEQB_Ext_1.5eafecc6.jpg',
    'https://brand-media-demo.front.vpgrp.net/experiences/crb-renault9/img/X071VEVP2WE_ENS_MDL2PSL1SERIELIM1_TEEQB_Ext_2.a0d52639.jpg',
    'https://brand-media-demo.front.vpgrp.net/experiences/crb-renault9/img/X071VEVP2WE_ENS_MDL2PSL1SERIELIM1_TEEQB_Ext_3.34732915.jpg',
    'https://brand-media-demo.front.vpgrp.net/experiences/crb-renault9/img/X071VEVP2WE_ENS_MDL2PSL1SERIELIM1_TEEQB_Ext_4.02620066.jpg',
    'https://brand-media-demo.front.vpgrp.net/experiences/crb-renault9/img/X071VEVP2WE_ENS_MDL2PSL1SERIELIM1_TEEQB_Ext_5.9167c89e.jpg',
    'https://brand-media-demo.front.vpgrp.net/experiences/crb-renault9/img/X071VEVP2WE_ENS_MDL2PSL1SERIELIM1_TEEQB_Ext_6.6dc1bd0c.jpg',
    'https://brand-media-demo.front.vpgrp.net/experiences/crb-renault9/img/X071VEVP2WE_ENS_MDL2PSL1SERIELIM1_TEEQB_Ext_7.c8a7d0c8.jpg',
    'https://brand-media-demo.front.vpgrp.net/experiences/crb-renault9/img/X071VEVP2WE_ENS_MDL2PSL1SERIELIM1_TEEQB_Ext_8.e7b23a06.jpg',
    'https://brand-media-demo.front.vpgrp.net/experiences/crb-renault9/img/X071VEVP2WE_ENS_MDL2PSL1SERIELIM1_TEEQB_Ext_9.4a23a12c.jpg',
    'https://brand-media-demo.front.vpgrp.net/experiences/crb-renault9/img/X071VEVP2WE_ENS_MDL2PSL1SERIELIM1_TEEQB_Ext_10.7e2a9f01.jpg',
    'https://brand-media-demo.front.vpgrp.net/experiences/crb-renault9/img/X071VEVP2WE_ENS_MDL2PSL1SERIELIM1_TEEQB_Ext_11.7658cf9b.jpg',
    'https://brand-media-demo.front.vpgrp.net/experiences/crb-renault9/img/X071VEVP2WE_ENS_MDL2PSL1SERIELIM1_TEEQB_Ext_12.c2731bf4.jpg',
    'https://brand-media-demo.front.vpgrp.net/experiences/crb-renault9/img/X071VEVP2WE_ENS_MDL2PSL1SERIELIM1_TEEQB_Ext_13.903fb2cb.jpg',
    'https://brand-media-demo.front.vpgrp.net/experiences/crb-renault9/img/X071VEVP2WE_ENS_MDL2PSL1SERIELIM1_TEEQB_Ext_14.5fbf7022.jpg',
    'https://brand-media-demo.front.vpgrp.net/experiences/crb-renault9/img/X071VEVP2WE_ENS_MDL2PSL1SERIELIM1_TEEQB_Ext_15.de65e63a.jpg',
    'https://brand-media-demo.front.vpgrp.net/experiences/crb-renault9/img/X071VEVP2WE_ENS_MDL2PSL1SERIELIM1_TEEQB_Ext_16.222c82a6.jpg',
    'https://brand-media-demo.front.vpgrp.net/experiences/crb-renault9/img/X071VEVP2WE_ENS_MDL2PSL1SERIELIM1_TEEQB_Ext_17.0b2bef1d.jpg',
    'https://brand-media-demo.front.vpgrp.net/experiences/crb-renault9/img/X071VEVP2WE_ENS_MDL2PSL1SERIELIM1_TEEQB_Ext_18.2e198ca7.jpg',
    'https://brand-media-demo.front.vpgrp.net/experiences/crb-renault9/img/X071VEVP2WE_ENS_MDL2PSL1SERIELIM1_TEEQB_Ext_19.f64b24dc.jpg',
    'https://brand-media-demo.front.vpgrp.net/experiences/crb-renault9/img/X071VEVP2WE_ENS_MDL2PSL1SERIELIM1_TEEQB_Ext_20.f52aea0a.jpg',
    'https://brand-media-demo.front.vpgrp.net/experiences/crb-renault9/img/X071VEVP2WE_ENS_MDL2PSL1SERIELIM1_TEEQB_Ext_21.799873b8.jpg',
    'https://brand-media-demo.front.vpgrp.net/experiences/crb-renault9/img/X071VEVP2WE_ENS_MDL2PSL1SERIELIM1_TEEQB_Ext_22.41ae2855.jpg',
    'https://brand-media-demo.front.vpgrp.net/experiences/crb-renault9/img/X071VEVP2WE_ENS_MDL2PSL1SERIELIM1_TEEQB_Ext_23.02de5a63.jpg',
    'https://brand-media-demo.front.vpgrp.net/experiences/crb-renault9/img/X071VEVP2WE_ENS_MDL2PSL1SERIELIM1_TEEQB_Ext_24.1844044a.jpg'
]" />
```

This component uses the <Img /\> component. This means that the provided images path must be relative to the `src/assets/img` folder.
