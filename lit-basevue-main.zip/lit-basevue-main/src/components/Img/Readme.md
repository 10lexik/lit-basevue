Simple image :

```vue
    <Frow>
        <FrowCol deskCols="1-6">
            <Img src="back-to-vp.svg" alt="retour à l'accueil" />
        </FrowCol>
    </Frow>
```

**Note that the image is located at `@/assets/img/back-to-vp.svg` but the full path must not be specified**
