```vue
    <Rating :rate="4" />
    <Rating :rate="4" :max="5" />
    <Rating :rate="4.0" :max="5" />
    <Rating :rate="3.1" :max="5" />
    <Rating :rate="3.5" :max="5" />
```
