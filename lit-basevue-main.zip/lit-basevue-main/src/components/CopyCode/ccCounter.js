let ccCounter = 0
export default ccCounter
