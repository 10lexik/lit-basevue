<b>Tracking is updated depending on the number of components used</b><br /><br />

Default CopyCode (code is setted with i18n)

```vue
<CopyCode />
```

Custom code so we can set 2 differents codes if we want, or more.

```vue
<CopyCode code="OUI" />
```
