Youtube Video (No visual example, due to doc specificities) :

```vue
<!--<Video videoId="B7YnAC0cqCk" :videoVars="{start: 214, autoplay: false}" />-->
```

Imported Video (No visual example, due to doc specificities and no default video) :

```vue
<!--<Video srcDesk="video-test-desk.mp4" srcMob="video-test-mob.mp4" sizeDesk="1976543" sizeMob="14325"/>-->
<!--<Video src="video-test.mp4" size="185437"/>-->
```

External Video
```vue
<Video src="https://media.veepee.com/v1/media/a00bea94-a72e-4dd1-ac68-2bebd1c75144" />
```
