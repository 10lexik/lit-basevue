Sticky :
```vue
    <Sticky />
    <Sticky type="full" position="bottom" trigger=".app__container" endTrigger=".bottom" :offset="0" />
    <Sticky >
        PERSONALISATION
    </Sticky>
```
