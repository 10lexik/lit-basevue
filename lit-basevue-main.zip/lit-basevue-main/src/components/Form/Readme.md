Simple usage :

```vue
<Form />
```
