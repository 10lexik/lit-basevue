import StoryViewer from './StoryViewer/StoryViewer.vue'
import StoryViewerPopin from './StoryViewerPopin/StoryViewerPopin.vue'
import StoryViewerHotspot from './StoryViewerHotspot/StoryViewerHotspot.vue'

export {
    StoryViewer,
    StoryViewerPopin,
    StoryViewerHotspot
}
