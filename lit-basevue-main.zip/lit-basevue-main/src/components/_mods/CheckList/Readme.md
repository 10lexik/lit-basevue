Customized CheckList :

```vue
<CheckList title="Mon équipe de Choc" text="La meilleure de toutes, à n'en point douter"
    :checkList="[
        'Un Grégoire sneaky',
        'Un Ghislain qui se prononce Guilain',
        'Une Emilie traîtresse',
        'Une Léa qui adore les pizze',
        'Une Pauline qui mange comme 2',
        'Un Guidou vénère',
        'Un moi',
        'Un Jeffrey, remets-moi des glaçons',
        'Un Hieu beaucoup trop bg',
        'Un Victor beaucoup trop drôle',
        'Un Vincent beaucoup trop fort',
        'Un Dboyax tech lead du cul',
        'Un Eliot casseur de trottis électriques',
        'Un Gwen critique maschallah++',
        'Un Pattou pas Patoche',
        'Un Jordax meilleur dev de France',
        'Une Hortense bientôt mère samèr',
        'Une Solange experte Excel du cul',
        'Un Nad bresson DJ',
        'Un Jo pas Lopez',
        'Un Damien pour le faire']"
    idBtn="idBuyTheSame" 
    backgroundColor="#ff4d4d" textColor="white" checkColor="white" />
```
