<template>
    <div class="tel">
        <vue-tel-input ref="inputTel" v-model="phone" v-bind="options"  ></vue-tel-input>
    </div>
</template>

<script src="./Tel.js"></script>
<style scoped lang="scss" src="./Tel.scss"></style>
