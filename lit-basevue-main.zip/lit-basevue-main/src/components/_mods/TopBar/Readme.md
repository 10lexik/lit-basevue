TopBar :

```vue
<TopBar idBtn="dumboBtnId" />
```
