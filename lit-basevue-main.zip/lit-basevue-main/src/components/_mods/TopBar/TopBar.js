'use strict'

export default {
    name: 'NavBar',
    props: {
        /**
         * The Dumbo button Id to use.
         */
        idBtn: {
            type: String
        }
    }
}
