Default Trip :

```vue
<Trip :destinations="[
    {
        img: 'https://edito.regionsjob.com/observatoire-metier/wp-content/uploads/sites/4/2018/06/Conseiller-voyages-Copier.jpg',
        offer: 'Jusqu\'à -30%',
        country: 'Indonésie',
        city: 'Bali & Lombok',
        location: 'Combiné Sthala - Katamaran - Meridien',
        rating: 5,
        price: 565,
        specialities: ['Premium', 'ACTIVITÉS INCLUSES'],
        idBtn: 'idGoNow'
    },
    {
        img: 'https://edito.regionsjob.com/observatoire-metier/wp-content/uploads/sites/4/2018/06/Conseiller-voyages-Copier.jpg',
        offer: 'Jusqu\'à -50%',
        country: 'France',
        city: 'Paris',
        location: 'Hôtel Leroy',
        rating: 4,
        price: 333,
        specialities: ['Boeuf Bourgignon', 'Jordax dort chez nous']
    },
    {
        img: 'https://edito.regionsjob.com/observatoire-metier/wp-content/uploads/sites/4/2018/06/Conseiller-voyages-Copier.jpg',
        offer: 'Jusqu\'à -30%',
        country: 'France',
        city: 'Paris',
        location: 'Hôtel Spartiate',
        rating: 4.5,
        price: 300,
        specialities: ['Steack Spartiate', 'Leonidas']
    }
]" />
```
