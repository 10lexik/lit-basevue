Product :

```vue
<Product img="https://pbs.twimg.com/profile_images/778418792846110720/X8VN2QdL_400x400.jpg"
        title="THIS ! IS ! SPARTAAA !" text="Spartans never surrend." style="width: 40%; margin: 0 auto"
        idBtn="idBuy" />
```
