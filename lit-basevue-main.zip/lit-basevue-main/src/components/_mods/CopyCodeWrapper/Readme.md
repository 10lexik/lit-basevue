<b>Tracking is updated depending on the number of components used</b><br /><br />

Default :

```vue
<CopyCodeWrapper />
```

With custom props :

```vue
<CopyCodeWrapper
    text="Toi aussi tu veux un phoque trop mignon à la maison ? Alors copie le code PHOQUE ci-dessous et obtiens le tien maintenant ! (Livré avec son bassin. Fonctionne sans piles. 2 poissons frais par jour nécessaires)"
    code="PHOQUE"
    idBtn="idBuyIt" />
```
