Voucher :
```vue
    <Voucher trackingId="idDumbo" src="https://www.veepee.fr/experiences/static-contents/confidential-policy/fr.pdf" />
```
